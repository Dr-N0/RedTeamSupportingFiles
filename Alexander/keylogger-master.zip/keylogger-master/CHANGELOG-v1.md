# Release Notes for Keylogger v1.x

## v1.2.0

- MIT License

## v1.1.0

- All source files moved to `src` directory.
- Functions to own files.
- Common `Makefile`.
