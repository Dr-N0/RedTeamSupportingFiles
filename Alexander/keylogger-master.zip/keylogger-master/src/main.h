
#ifndef _MAIN_H
#define _MAIN_H

//#include <cstdlib>
#include <iostream>
//#include <sstream>
#include <fstream>
#include <string>

#include <stdio.h>
#include <time.h>
#include <windows.h>

#include "config.h"
#include "functions.h"

#endif /* _MAIN_H */
