
#ifndef _CONFIG_H
#define _CONFIG_H

#define PROJECT_NAME "Keylogger"
#define PROJECT_VERSION_MAJOR 1
#define PROJECT_VERSION_MINOR 2
#define PROJECT_VERSION_PATCH 0
#define PROJECT_COPYRIGHT "Copyright (C) 2009 Christian Mayer <http://fox21.at>"
#define FILEEXT ".log"
#define DEBUG

#endif /* _CONFIG_H */
