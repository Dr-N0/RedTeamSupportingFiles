
#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <string>

#include <windows.h>
#include <stdlib.h>

using namespace std;

string intToString(int);
string getCurrDir();
string getSelfPath();
string dirBasename(string);

#endif /* _FUNCTIONS_H */
